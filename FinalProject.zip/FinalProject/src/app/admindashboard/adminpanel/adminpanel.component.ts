import { Component } from '@angular/core';
import { MyserviceService } from 'src/app/myservice.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-adminpanel',
  templateUrl: './adminpanel.component.html',
  styleUrls: ['./adminpanel.component.css']
})
export class AdminpanelComponent {

  toggle?:boolean=false;
  u?:string;

  constructor(private serv:MyserviceService,private route:Router){
  }
  ngOnInit()
  {
    this.u=MyserviceService.username
  }

  categorybtn()
  {
      this.toggle=true;
  }

  productbtn()
  {
    this.toggle=false;

  }

  
}
