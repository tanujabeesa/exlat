import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule} from '@angular/common/http'
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CategoryComponent } from './categorydetails/category/category.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxPaginationModule } from 'ngx-pagination';
import { ListproductComponent } from './productdetails/listproduct/listproduct.component';
import { AdminpanelComponent } from './admindashboard/adminpanel/adminpanel.component';
import { CustomerpanelComponent } from './customerdashboard/customerpanel/customerpanel.component';
import { RouterModule } from '@angular/router';
import { PagenotfoundComponent } from './pagenotfoundcomp/pagenotfound/pagenotfound.component';
import { FlexLayoutModule } from '@angular/flex-layout';

import { SignupComponent } from './signup/signup.component';
import { SigninComponent } from './signin/signin.component';
import { HttpInterceptorService } from './http-interceptor.service';
import {  HTTP_INTERCEPTORS }    from '@angular/common/http';

import { AboutComponent } from './about/about.component';
import { JewelleryComponent } from './jewellery/jewellery.component';
import { ContactusComponent } from './contactus/contactus.component';
import { HomeComponent } from './home/home.component';
import { category } from './category';
import { UserloginComponent } from './userlogin/userlogin.component';
import { MainhomeComponent } from './mainhome/mainhome.component';
import { product } from './product';


@NgModule({
  declarations: [
    AppComponent,
    CategoryComponent,
    ListproductComponent,
    AdminpanelComponent,
    CustomerpanelComponent,
    PagenotfoundComponent, SignupComponent, SigninComponent, AboutComponent, JewelleryComponent, ContactusComponent, HomeComponent, UserloginComponent, MainhomeComponent,

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,HttpClientModule,ReactiveFormsModule,NgxPaginationModule,FormsModule,FlexLayoutModule,
    RouterModule.forRoot([
        {path:"admin",component:AdminpanelComponent},

        {path:"customer",component:CustomerpanelComponent},
        { path: 'signin', component: SigninComponent },
        { path: 'signup', component: SignupComponent },
        {path:'jewellery',component:JewelleryComponent},
        {path:'contactus',component:ContactusComponent},
        {path:'home',component:HomeComponent},
        {path:'about',component:AboutComponent},
        {path:'category',component:CategoryComponent},
       
        { path: '', component:MainhomeComponent },
       // {path:"**",component:PagenotfoundComponent},
    ])
  ],
  providers: [{   provide: HTTP_INTERCEPTORS,
    useClass: HttpInterceptorService,
    multi: true
}],
  bootstrap: [AppComponent],exports:[RouterModule]
})
export class AppModule { }
