export class productbycategory
{
  catid?:number=0;
  catnm?:string=''
	prid?:number=0;
	prnm?:string='';
	price?:number=0;
  descrip?:string;
  qty?:number;
	reorder?:number;
	pic?:Blob;
}
