export class category
{
catid:number=0;
catnm:string='';
}
