import { Component } from '@angular/core';
import { MyserviceService } from '../myservice.service';


@Component({
  selector: 'app-contactus',
  templateUrl: './contactus.component.html',
  styleUrls: ['./contactus.component.css']
})
export class ContactusComponent {
  em:any
  constructor( private serv:MyserviceService){

  }
sendmail() {
  this.serv.mail(this.em).subscribe( Response=>alert ("Mail Send Sucessfully"))
}

}
