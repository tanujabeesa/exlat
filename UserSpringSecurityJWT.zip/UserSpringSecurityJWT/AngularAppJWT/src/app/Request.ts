export interface Request {
	userName: string;
	userPwd: string;
	roles?: string[];
}
